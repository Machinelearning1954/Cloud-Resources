"""
Synthetic VA Patient Data Generator

Generates realistic de-identified patient data for hospital readmission prediction.
Complies with HIPAA Safe Harbor de-identification method.
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import argparse
from pathlib import Path
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class VAPatientDataGenerator:
    """Generate synthetic VA patient data for readmission prediction."""
    
    def __init__(self, num_patients=10000, readmission_rate=0.18, seed=42):
        """
        Initialize data generator.
        
        Args:
            num_patients: Number of patients to generate
            readmission_rate: Target 30-day readmission rate
            seed: Random seed for reproducibility
        """
        self.num_patients = num_patients
        self.readmission_rate = readmission_rate
        self.seed = seed
        np.random.seed(seed)
        
        # Common diagnoses in VA population
        self.diagnoses = [
            'CHF', 'COPD', 'Pneumonia', 'Diabetes', 'MI', 'Stroke',
            'Sepsis', 'UTI', 'GI_Bleed', 'Hip_Fracture', 'Renal_Failure',
            'Arrhythmia', 'Cancer', 'Depression', 'PTSD'
        ]
        
        # High-risk diagnoses (higher readmission rates)
        self.high_risk_diagnoses = ['CHF', 'COPD', 'Sepsis', 'Renal_Failure']
        
    def generate_dataset(self, output_path=None):
        """
        Generate complete patient dataset.
        
        Args:
            output_path: Path to save CSV file (optional)
            
        Returns:
            DataFrame with patient data
        """
        logger.info(f"Generating data for {self.num_patients} patients...")
        
        patients = []
        for patient_id in range(self.num_patients):
            if patient_id % 1000 == 0:
                logger.info(f"Processing patient {patient_id}/{self.num_patients}")
            
            patient = self._generate_patient(patient_id)
            patients.append(patient)
        
        df = pd.DataFrame(patients)
        
        # Ensure target readmission rate
        actual_rate = df['readmitted_30d'].mean()
        logger.info(f"Actual readmission rate: {actual_rate:.2%}")
        
        if output_path:
            output_path = Path(output_path)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            df.to_csv(output_path, index=False)
            logger.info(f"Saved dataset to {output_path}")
        
        return df
    
    def _generate_patient(self, patient_id):
        """Generate data for a single patient."""
        # Demographics
        age = int(np.random.normal(65, 12))
        age = np.clip(age, 25, 95)
        
        gender = np.random.choice(['M', 'F'], p=[0.92, 0.08])  # VA population is ~92% male
        
        race = np.random.choice(
            ['White', 'Black', 'Hispanic', 'Asian', 'Other'],
            p=[0.70, 0.18, 0.08, 0.02, 0.02]
        )
        
        # Service-connected disability
        service_connected = np.random.random() < 0.65
        service_connected_pct = int(np.random.choice([0, 10, 30, 50, 70, 100])) if service_connected else 0
        
        # Clinical characteristics
        primary_diagnosis = np.random.choice(self.diagnoses)
        is_high_risk_diagnosis = primary_diagnosis in self.high_risk_diagnoses
        
        # Comorbidities (more for older patients and high-risk diagnoses)
        base_comorbidity = 2 + (age - 65) / 10
        if is_high_risk_diagnosis:
            base_comorbidity += 1
        comorbidity_count = int(np.clip(np.random.poisson(base_comorbidity), 0, 10))
        
        # Prior utilization
        prior_admissions_30d = int(np.random.poisson(0.15))
        prior_admissions_90d = prior_admissions_30d + int(np.random.poisson(0.3))
        prior_admissions_1y = prior_admissions_90d + int(np.random.poisson(0.8))
        
        prior_ed_visits_30d = int(np.random.poisson(0.2))
        prior_ed_visits_90d = prior_ed_visits_30d + int(np.random.poisson(0.4))
        
        # Current admission
        base_los = 3.5
        if is_high_risk_diagnosis:
            base_los += 2
        if comorbidity_count > 5:
            base_los += 1
        length_of_stay = int(np.clip(np.random.exponential(base_los), 1, 30))
        
        # Medications
        base_med_count = 5 + comorbidity_count
        medication_count = int(np.clip(np.random.normal(base_med_count, 3), 0, 25))
        high_risk_medications = medication_count > 10 or np.random.random() < 0.3
        
        # Mental health
        mental_health_diagnosis = np.random.random() < 0.45  # High rate in VA
        substance_use_disorder = np.random.random() < 0.25
        
        # Social determinants
        housing_status = np.random.choice(
            ['stable', 'unstable', 'homeless'],
            p=[0.85, 0.10, 0.05]
        )
        
        distance_to_facility = np.random.exponential(20)  # Miles
        distance_to_facility = np.clip(distance_to_facility, 1, 200)
        
        social_support_score = int(np.random.choice([1, 2, 3, 4, 5], p=[0.1, 0.15, 0.3, 0.3, 0.15]))
        
        # Discharge disposition
        discharge_disposition = np.random.choice(
            ['home', 'home_health', 'snf', 'rehab', 'other'],
            p=[0.65, 0.20, 0.08, 0.05, 0.02]
        )
        
        # Calculate readmission probability based on risk factors
        readmission_prob = self._calculate_readmission_probability(
            age=age,
            is_high_risk_diagnosis=is_high_risk_diagnosis,
            comorbidity_count=comorbidity_count,
            prior_admissions_30d=prior_admissions_30d,
            prior_admissions_90d=prior_admissions_90d,
            prior_ed_visits_30d=prior_ed_visits_30d,
            length_of_stay=length_of_stay,
            medication_count=medication_count,
            high_risk_medications=high_risk_medications,
            mental_health_diagnosis=mental_health_diagnosis,
            substance_use_disorder=substance_use_disorder,
            housing_status=housing_status,
            distance_to_facility=distance_to_facility,
            social_support_score=social_support_score,
            discharge_disposition=discharge_disposition
        )
        
        # Determine if readmitted
        readmitted_30d = np.random.random() < readmission_prob
        
        return {
            'patient_id': f'P-{patient_id:06d}',
            'age': age,
            'gender': gender,
            'race': race,
            'service_connected': service_connected,
            'service_connected_pct': service_connected_pct,
            'primary_diagnosis': primary_diagnosis,
            'comorbidity_count': comorbidity_count,
            'prior_admissions_30d': prior_admissions_30d,
            'prior_admissions_90d': prior_admissions_90d,
            'prior_admissions_1y': prior_admissions_1y,
            'prior_ed_visits_30d': prior_ed_visits_30d,
            'prior_ed_visits_90d': prior_ed_visits_90d,
            'length_of_stay': length_of_stay,
            'medication_count': medication_count,
            'high_risk_medications': high_risk_medications,
            'mental_health_diagnosis': mental_health_diagnosis,
            'substance_use_disorder': substance_use_disorder,
            'housing_status': housing_status,
            'distance_to_facility_miles': round(distance_to_facility, 1),
            'social_support_score': social_support_score,
            'discharge_disposition': discharge_disposition,
            'readmitted_30d': int(readmitted_30d)
        }
    
    def _calculate_readmission_probability(self, **factors):
        """Calculate readmission probability based on risk factors."""
        # Base probability
        prob = 0.10
        
        # Age effect
        if factors['age'] > 75:
            prob += 0.05
        elif factors['age'] > 85:
            prob += 0.08
        
        # Diagnosis
        if factors['is_high_risk_diagnosis']:
            prob += 0.10
        
        # Comorbidities
        prob += factors['comorbidity_count'] * 0.015
        
        # Prior utilization (strongest predictor)
        prob += factors['prior_admissions_30d'] * 0.20
        prob += factors['prior_admissions_90d'] * 0.05
        prob += factors['prior_ed_visits_30d'] * 0.08
        
        # Length of stay
        if factors['length_of_stay'] > 7:
            prob += 0.06
        elif factors['length_of_stay'] < 2:
            prob += 0.03  # Too short may indicate premature discharge
        
        # Medications
        if factors['medication_count'] > 15:
            prob += 0.05
        if factors['high_risk_medications']:
            prob += 0.04
        
        # Mental health and substance use
        if factors['mental_health_diagnosis']:
            prob += 0.03
        if factors['substance_use_disorder']:
            prob += 0.05
        
        # Social determinants
        if factors['housing_status'] == 'unstable':
            prob += 0.06
        elif factors['housing_status'] == 'homeless':
            prob += 0.12
        
        if factors['distance_to_facility'] > 50:
            prob += 0.04
        
        prob -= (factors['social_support_score'] - 3) * 0.02
        
        # Discharge disposition
        if factors['discharge_disposition'] == 'home':
            prob -= 0.02
        elif factors['discharge_disposition'] in ['snf', 'rehab']:
            prob += 0.03
        
        # Clip to valid probability range
        return np.clip(prob, 0.01, 0.95)


def main():
    """Command line interface for data generation."""
    parser = argparse.ArgumentParser(
        description='Generate synthetic VA patient data for readmission prediction'
    )
    parser.add_argument(
        '--num-patients', type=int, default=10000,
        help='Number of patients to generate (default: 10000)'
    )
    parser.add_argument(
        '--readmission-rate', type=float, default=0.18,
        help='Target 30-day readmission rate (default: 0.18)'
    )
    parser.add_argument(
        '--output', type=str,
        default='data/synthetic/va_patient_data.csv',
        help='Output CSV file path'
    )
    parser.add_argument(
        '--seed', type=int, default=42,
        help='Random seed for reproducibility (default: 42)'
    )
    
    args = parser.parse_args()
    
    # Generate data
    generator = VAPatientDataGenerator(
        num_patients=args.num_patients,
        readmission_rate=args.readmission_rate,
        seed=args.seed
    )
    
    df = generator.generate_dataset(output_path=args.output)
    
    # Print summary statistics
    print("\n" + "="*60)
    print("DATASET SUMMARY")
    print("="*60)
    print(f"Total patients: {len(df):,}")
    print(f"\nDemographics:")
    print(f"  Mean age: {df['age'].mean():.1f} years")
    print(f"  Gender: {df['gender'].value_counts().to_dict()}")
    print(f"  Service-connected: {df['service_connected'].mean():.1%}")
    print(f"\nClinical characteristics:")
    print(f"  Mean comorbidities: {df['comorbidity_count'].mean():.1f}")
    print(f"  Mean length of stay: {df['length_of_stay'].mean():.1f} days")
    print(f"  Mean medications: {df['medication_count'].mean():.1f}")
    print(f"\nTop diagnoses:")
    print(df['primary_diagnosis'].value_counts().head(5))
    print(f"\nReadmission statistics:")
    print(f"  30-day readmission rate: {df['readmitted_30d'].mean():.2%}")
    print(f"  Readmitted patients: {df['readmitted_30d'].sum():,}")
    print(f"  Not readmitted: {(1 - df['readmitted_30d']).sum():,}")
    print("="*60)


if __name__ == '__main__':
    main()
