import PyPDF2

def extract_text_from_pdf(pdf_path):
    text = ""
    with open(pdf_path, 'rb') as file:
        reader = PyPDF2.PdfReader(file)
        for page_num in range(len(reader.pages)):
            page = reader.pages[page_num]
            text += page.extract_text()
    return text

if __name__ == "__main__":
    pdf_text = extract_text_from_pdf("/home/ubuntu/guidelines.pdf")
    with open("/home/ubuntu/guidelines_text.txt", "w") as text_file:
        text_file.write(pdf_text)
